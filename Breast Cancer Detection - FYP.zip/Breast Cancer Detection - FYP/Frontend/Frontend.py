import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
from tkinter import ttk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import cv2
import unet
import numpy as np
import tensorflow
modelDense= tensorflow.keras.models.load_model('Models/DenseNet.h5')
modelMobile= tensorflow.keras.models.load_model('Models/MobileNet.h5')
modelCNN= tensorflow.keras.models.load_model('Models/CNN.h5')
modelANN= tensorflow.keras.models.load_model('Models/ANN.h5')
def predictResult(img, model):
            img = np.asarray(img)
            img = cv2.resize(img,(224,224),interpolation = cv2.INTER_CUBIC)
            height, width = img.shape[:2]
            img = img.astype('float32')/255.0
            test_image1 = np.expand_dims(img, axis = 0)
            result = model.predict(test_image1)
            result = np.argmax(result)
            return result

class ImageApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Image App")
        self.root.geometry("1366x768")
        self.root.resizable(True, True)
        self.root.wm_attributes('-transparentcolor', '#f0f0f0')

        # Create background image
        background_image = Image.open("images/b1.jpg")
        background_image=background_image.resize((1366,768))
        background_photo = ImageTk.PhotoImage(background_image)
        background_label = tk.Label(self.root, image=background_photo)
        background_label.image = background_photo
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Create logo and company name
        logo = Image.open("images/logo.png")
        logo = logo.resize((80, 80), Image.ANTIALIAS)
        logo_photo = ImageTk.PhotoImage(logo)
        logo_display = tk.Label(self.root, image=logo_photo)
        logo_display.image = logo_photo
        logo_display.pack(pady=45)

        company_name = tk.Label(self.root, text="Breast Cancer Detection", font=("Helvetica", 16), fg="#FFFFFF")
        company_name.pack()

        self.image_path = ""
        self.image_display = tk.Label(self.root)
        self.image_display.pack(pady=20)

        # Button to select image
        select_image_button = tk.Button(self.root, text="Select Image", font=("Helvetica", 12), bg="#F6D365", fg="#292929", activebackground="#F6D365", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.select_image)
        select_image_button.pack()

        # Frame to hold message buttons
        message_frame = tk.Frame(self.root)
        message_frame.pack(pady=20)

        # Buttons to display messages
        message1_button = tk.Button(message_frame, text="DenseNet", font=("Helvetica", 12), bg="#70C1B3", fg="#292929", activebackground="#70C1B3", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message1)
        message1_button.pack(side="left", padx=10)

        message2_button = tk.Button(message_frame, text="MobileNet", font=("Helvetica", 12), bg="#FF9F1C", fg="#292929", activebackground="#FF9F1C", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message2)
        message2_button.pack(side="left", padx=10)

        message3_button = tk.Button(message_frame, text="CNN", font=("Helvetica", 12), bg="#EF476F", fg="#FFF", activebackground="#EF476F", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message3)
        message3_button.pack(side="left", padx=10)

        message4_button = tk.Button(message_frame, text="RNN", font=("Helvetica", 12), bg="#43AA8B", fg="#FFF", activebackground="#43AA8B", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message4)
        message4_button.pack(side="left", padx=10)
        
        message5_button = tk.Button(message_frame, text="Hospitals", font=("Helvetica", 12), bg="#880808", fg="#FFF", activebackground="#43AA8B", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message5)
        message5_button.pack(side="left", padx=10)

        message6_button = tk.Button(message_frame, text="First Aid", font=("Helvetica", 12), bg="#880808", fg="#FFF", activebackground="#43AA8B", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message6)
        message6_button.pack(side="left", padx=10)

        message7_button = tk.Button(message_frame, text="Confusion", font=("Helvetica", 12), bg="#880808", fg="#FFF", activebackground="#43AA8B", activeforeground="#FFF", bd=0, padx=10, pady=5, command=self.display_message7)
        message7_button.pack(side="left", padx=10)

    def select_image(self):
        self.image_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg;*.jpeg;*.png")])
        if self.image_path:
            image = Image.open(self.image_path)
            image = image.resize((350, 350), Image.ANTIALIAS)
            photo = ImageTk.PhotoImage(image)
            self.image_display.config(image=photo)
            self.image_display.image = photo

    def display_message1(self):
        img=cv2.imread(self.image_path)
        img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        result=predictResult(img, modelDense)
        if (result==0):
            ans=messagebox.askquestion("DenseNet Result", "Patient is Sick \n accuracy 97.956562\n\nWant to see nearest hospitals")
            if ans=='yes':
                messagebox.showinfo("Hospitals in Faisalabad", " HOSPITALS:             ADDRESS \n\nAllied Hospital |  Dr. Tusi Rd, Faisalabad, Punjab\n\nCivil Hospital | 6264+X54, Faisalabad, Punjab 38000\n\nGeneral Hospital | C2VW+667, Block C Ghulam Muhammad Abad, Faisalabad, Punjab")

        elif (result==1):
              messagebox.showinfo("DenseNet Result", "Patient is Healthy \n accuracy 97.956562")
        else:
              messagebox.showinfo("DenseNet Result", "Error")

    def display_message2(self):
        img=cv2.imread(self.image_path)
        img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        result=predictResult(img, modelMobile)
        if (result==0):
            ans=messagebox.askquestion("MobileNet Result", "Patient is Sick \n accuracy 96.8598654\n\nWant to see nearest hospitals")
            if ans=='yes':
                messagebox.showinfo("Hospitals in Faisalabad", " HOSPITALS:             ADDRESS \n\nAllied Hospital |  Dr. Tusi Rd, Faisalabad, Punjab\n\nCivil Hospital | 6264+X54, Faisalabad, Punjab 38000\n\nGeneral Hospital | C2VW+667, Block C Ghulam Muhammad Abad, Faisalabad, Punjab")

        elif (result==1):
                messagebox.showinfo("MobileNet Result", "Patient is Healthy \n accuracy 96.8598654")
        else:
                messagebox.showinfo("MobileNet Result", "Error")

    def display_message3(self):
        img=cv2.imread(self.image_path)
        img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        result=predictResult(img, modelCNN)
        if (result==0):
            ans=messagebox.askquestion("CNN Result", "Patient is Sick \n accuracy 95.3532658\n\nWant to see nearest hospitals")
            if ans=='yes':
                messagebox.showinfo("Hospitals in Faisalabad", " HOSPITALS:             ADDRESS \n\nAllied Hospital |  Dr. Tusi Rd, Faisalabad, Punjab\n\nCivil Hospital | 6264+X54, Faisalabad, Punjab 38000\n\nGeneral Hospital | C2VW+667, Block C Ghulam Muhammad Abad, Faisalabad, Punjab")

        elif (result==1):
            messagebox.showinfo("CNN Result", "Patient is Healthy  \n accuracy 95.3532658")
        else:
            messagebox.showinfo("CNN Result", "Error")
    
    def display_message4(self):
        img=cv2.imread(self.image_path)
        img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        result=predictResult(img, modelANN)
        if (result==0):
            ans=messagebox.askquestion("ANN Result", "Patient is Sick \n accuracy 94.1523135\n\nWant to see nearest hospitals")
            if ans=='yes':
                messagebox.showinfo("Hospitals in Faisalabad", " HOSPITALS:             ADDRESS \n\nAllied Hospital |  Dr. Tusi Rd, Faisalabad, Punjab\n\nCivil Hospital | 6264+X54, Faisalabad, Punjab 38000\n\nGeneral Hospital | C2VW+667, Block C Ghulam Muhammad Abad, Faisalabad, Punjab")

        elif (result==1):
            messagebox.showinfo("ANN Result", "Patient is Healthy \n accuracy 94.1523135")
        else:
            messagebox.showinfo("ANN Result", "Error")

    def display_message5(self):
        messagebox.showinfo("Hospitals in Faisalabad", " HOSPITALS:             ADDRESS \n\nAllied Hospital |  Dr. Tusi Rd, Faisalabad, Punjab\n\nCivil Hospital | 6264+X54, Faisalabad, Punjab 38000\n\nGeneral Hospital | C2VW+667, Block C Ghulam Muhammad Abad, Faisalabad, Punjab")

    def display_message6(self):
        messagebox.showinfo("First Aid", "If you find Breast Cancer please dont be panic it treatable\n\nPlease Visit any mentiond hospitals as soon as posible\n\nDon't wear any Itcing Cloth\n\nDo not Try to press any abnormility by yourself")

    def display_message7(self):
        class ImageApp2:
            def __init__(self):
                self.root = tk.Toplevel()
                self.root.title("Image App")
                self.root.geometry("694x308")
                self.root.resizable(True, True)

        # Create background image
                background_image = Image.open("images/confusion.png")
                background_photo = ImageTk.PhotoImage(background_image)
                background_label = tk.Label(self.root, image=background_photo)
                background_label.image = background_photo
                background_label.place(x=0, y=0, relwidth=1, relheight=1)

      
            def run(self):
                self.root.mainloop()

        if __name__ == '__main__':
            app = ImageApp2()
            app.run()


    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = ImageApp()
    app.run()
